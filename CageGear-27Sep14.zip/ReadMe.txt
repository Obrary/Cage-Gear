Product: Cage Gear, September 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/designs/cage-gear

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
The Cage Gear is designed to be cut on the laser cutter on plywood.